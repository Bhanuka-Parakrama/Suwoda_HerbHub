<footer class="bg-success text-center text-white py-3 mt-auto">
    &copy; 2025 Suwoda Admin Panel. All rights reserved.
</footer>