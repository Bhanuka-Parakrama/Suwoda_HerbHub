<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>header</title>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

</head>
<body>
      <header class="bg-success text-white py-3 mb-4 position-relative">
        <img src="../assets/images/Logo.jpg" alt="Logo"
             style="width: 70px; height: 70px; object-fit: cover; border-radius: 50%; position: absolute; left: 48px; top: 50%; transform: translateY(-50%); border: 3px solid #fff;">
        <h1 class="mb-0 text-center" style="margin:0; font-size:2.5rem;">
            <i class="bi bi-speedometer2 me-2"></i>Suwoda Admin Panel
        </h1>
    </header>


     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script>
</body>
</html>